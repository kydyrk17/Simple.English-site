
function checkAnswer(answer) {
    const result = document.getElementById("result");
    if (answer === "went") {
        result.textContent = "Correct!";
        result.style.color = "green";
    } else {
        result.textContent = "Try again!";
        result.style.color = "red";
    }
}
